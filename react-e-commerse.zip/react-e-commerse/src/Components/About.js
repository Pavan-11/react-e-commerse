import React from "react";

const About = () => {
    return(
        <>
        <h1 style={{textAlign:'center', color:'Gray',margin:'3rem 0rem 3rem 0rem'}}>
            About us
        </h1>
        <div style={{ height: '70vh' }}>
            <p >Lorem ipsum dolor, sit amet consectetur adipisicing elit. Laudantium atque mollitia voluptate quos unde dolorum id, praesentium sit natus enim nemo aliquid distinctio perferendis perspiciatis labore minus ratione. Nostrum nemo tenetur assumenda omnis alias distinctio atque blanditiis dolore facilis minus, neque autem. Quia, dolor. Corporis, necessitatibus veniam ut modi nihil maxime maiores rem autem aliquid. Cumque nisi ipsam quasi quod molestiae eos saepe repellendus accusantium.</p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde magni ab fuga sint obcaecati ipsum alias quasi, voluptates eaque ut voluptatum voluptas iste commodi blanditiis.</p>
            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Reiciendis natus fuga molestiae autem recusandae nisi ducimus ad a dolorem unde vero provident optio maiores earum, minus eaque modi, consequuntur aliquam molestias accusantium obcaecati nihil similique.</p>
        </div>

        </>
    )
}
export default About;