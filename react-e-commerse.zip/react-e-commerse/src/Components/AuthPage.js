import AuthForm from "./AuthForm";
const AuthPage = () => {
    return <AuthForm />;
};

export default AuthPage;
